#ifndef GAME_H
#define GAME_H

#include <thread>
#include <mutex>
#include <condition_variable>
#include <random>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include "SDL.h"
#include "controller.h"
#include "renderer.h"
#include "snake.h"

enum class Difficulty { Easy, Medium, Hard };
class Game {
 public:
  Game(std::size_t grid_width, std::size_t grid_height, Difficulty difficulty, std::string const &currentPlayerName);
  ~Game();
  void Run(Controller const &controller, Renderer &renderer,
           std::size_t target_frame_duration);
  int GetScore() const;
  int GetSize() const;
  void PlaceFood();
  
 private:
  Snake snake;
  SDL_Point food;
  SDL_Point penalty_food; 
  std::vector<SDL_Point> walls; 
  Snake ai_snake;  

  std::random_device dev;
  std::mt19937 engine;
  std::uniform_int_distribution<int> random_w;
  std::uniform_int_distribution<int> random_h;

  int score{0};
  std::vector<int> highScores;
  std::vector<std::string> playerNames;
  std::string const &currentPlayerName;
  bool running{true};
  void UpdateThread();
  void LoadHighScores();
  void SaveHighScores();
  void UpdateHighScores(std::string const &playerName, int &newScore);

  
  std::thread event_thread;
  std::mutex mtx;
  std::condition_variable cv;
  bool data_ready{false};

  void PlacePenaltyFood(); 
  void PlaceWalls(); 
  void Update();
  void SetSpeed(Difficulty &difficulty);
  void CheckCollisionWithAISnake();
};

#endif