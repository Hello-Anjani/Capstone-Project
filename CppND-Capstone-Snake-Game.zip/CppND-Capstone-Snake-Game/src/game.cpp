#include "game.h"
#include <iostream>
#include "SDL.h"

Game::Game(std::size_t grid_width, std::size_t grid_height, Difficulty difficulty, std::string const &currentPlayerName)
    : snake(grid_width, grid_height),
      ai_snake(grid_width, grid_height),
      engine(dev()),
      currentPlayerName(currentPlayerName),
      random_w(0, static_cast<int>(grid_width - 1)),
      random_h(0, static_cast<int>(grid_height - 1))
{
  PlaceFood();
  SetSpeed(difficulty);
  LoadHighScores();
  PlacePenaltyFood();
  PlaceWalls();
  event_thread = std::thread(&Game::UpdateThread, this);
  std::cout << "initializing" << "\n";
}

Game::~Game()
{
  {
    std::lock_guard<std::mutex> lock(mtx);
    running = false;
    data_ready = true;
  }
  cv.notify_one();
  if (event_thread.joinable())
  {
    event_thread.join();
  }
}

void Game::SetSpeed(Difficulty &difficulty)
{
  switch (difficulty)
  {
  case Difficulty::Easy:
    snake.speed = 0.05f;
    break;
  case Difficulty::Medium:
    snake.speed = 0.1f;
    break;
  case Difficulty::Hard:
    snake.speed = 0.15f;
    break;
  }
}

void Game::LoadHighScores()
{
  std::ifstream file("highscores.txt");
  if (!file)
  {
    std::cerr << "Unable to open highscores.txt. Creating a new file.\n";
    std::ofstream createFile("highscores.txt");
    return;
  }
  std::string name;
  int score;
  while (file >> name >> score)
  {
    playerNames.push_back(name);
    highScores.push_back(score);
  }
  auto comparator = [](const std::pair<std::string, int> &a, const std::pair<std::string, int> &b)
  {
    return a.second > b.second;
  };
  std::vector<std::pair<std::string, int>> scores;
  for (size_t i = 0; i < highScores.size(); ++i)
  {
    scores.push_back({playerNames[i], highScores[i]});
  }
  std::sort(scores.begin(), scores.end(), comparator);
  playerNames.clear();
  highScores.clear();
  for (const auto &score : scores)
  {
    playerNames.push_back(score.first);
    highScores.push_back(score.second);
  }
}

void Game::SaveHighScores()
{
  std::ofstream file("highscores.txt");
  if (!file)
  {
    std::cerr << "Unable to open highscores.txt\n";
    return;
  }
  for (size_t i = 0; i < highScores.size(); ++i)
  {
    file << playerNames[i] << " " << highScores[i] << std::endl;
  }
}

void Game::UpdateHighScores(std::string const &playerName, int &newScore)
{
  playerNames.push_back(playerName);
  highScores.push_back(newScore);
  std::vector<std::pair<std::string, int>> scores;
  for (size_t i = 0; i < highScores.size(); ++i)
  {
    scores.push_back({playerNames[i], highScores[i]});
  }
  auto comparator = [](const std::pair<std::string, int> &a, const std::pair<std::string, int> &b)
  {
    return a.second > b.second;
  };
  std::sort(scores.begin(), scores.end(), comparator);
  if (scores.size() > 10)
  {
    scores.resize(10); // Keep only top 10 scores
  }
  playerNames.clear();
  highScores.clear();
  for (const auto &score : scores)
  {
    playerNames.push_back(score.first);
    highScores.push_back(score.second);
  }
  SaveHighScores();
}

void Game::Run(Controller const &controller, Renderer &renderer,
               std::size_t target_frame_duration)
{
  std::cout << "inside run" << "\n";
  Uint32 title_timestamp = SDL_GetTicks();
  Uint32 frame_start;
  Uint32 frame_end;
  Uint32 frame_duration;
  int frame_count = 0;
  running = true;
  bool paused = false;

  while (running)
  {
    frame_start = SDL_GetTicks();

    // Input, Update, Render - the main game loop.
    controller.HandleInput(running, snake, paused);
    if (!paused)
    {
      Update();
    }
    renderer.Render(snake, food, penalty_food, walls, ai_snake);

    if (!snake.alive || !ai_snake.alive)
    {
      renderer.RenderGameOver();
      SDL_Delay(3000); // Display game over message for 3 seconds
      running = false;
      break;
    }

    frame_end = SDL_GetTicks();
    // Keep track of how long each loop through the input/update/render cycle
    // takes.
    frame_count++;
    frame_duration = frame_end - frame_start;

    // After every second, update the window title.
    if (frame_end - title_timestamp >= 1000)
    {
      renderer.UpdateWindowTitle(score, frame_count);
      frame_count = 0;
      title_timestamp = frame_end;
    }

    // If the time for this frame is too small (i.e. frame_duration is
    // smaller than the target ms_per_frame), delay the loop to
    // achieve the correct frame rate.
    if (frame_duration < target_frame_duration)
    {
      SDL_Delay(target_frame_duration - frame_duration);
    }

    {
      std::lock_guard<std::mutex> lock(mtx);
      data_ready = true;
    }
    cv.notify_one();
  }
  UpdateHighScores(currentPlayerName, score);
  renderer.DisplayHighScores(playerNames, highScores);
  {
    std::lock_guard<std::mutex> lock(mtx);
    running = false;
    data_ready = true;
  }
  cv.notify_one();
  event_thread.join();
}

void Game::PlaceFood()
{
  int x, y;
  while (true)
  {
    x = random_w(engine);
    y = random_h(engine);
    // Check that the location is not occupied by a snake item or wall before placing food.
    if (!snake.SnakeCell(x, y) && std::none_of(walls.begin(), walls.end(), [x, y](SDL_Point const &point)
                                               { return point.x == x && point.y == y; }))
    {
      food.x = x;
      food.y = y;
      return;
    }
  }
}

void Game::PlacePenaltyFood()
{
  int x, y;
  while (true)
  {
    x = random_w(engine);
    y = random_h(engine);
    // Check that the location is not occupied by a snake item, regular food, or wall before placing penalty food.
    if (!snake.SnakeCell(x, y) && !(food.x == x && food.y == y) && std::none_of(walls.begin(), walls.end(), [x, y](SDL_Point const &point)
                                                                                { return point.x == x && point.y == y; }))
    {
      penalty_food.x = x;
      penalty_food.y = y;
      return;
    }
  }
}

void Game::PlaceWalls()
{
  int num_walls = 5; // Example number of walls
  walls.clear();
  for (int i = 0; i < num_walls; ++i)
  {
    int x, y;
    while (true)
    {
      x = random_w(engine);
      y = random_h(engine);
      // Ensure the wall does not overlap with snake, food, or other walls.
      if (!snake.SnakeCell(x, y) && !(food.x == x && food.y == y) && std::none_of(walls.begin(), walls.end(), [x, y](SDL_Point const &point)
                                                                                  { return point.x == x && point.y == y; }))
      {
        walls.push_back(SDL_Point{x, y});
        break;
      }
    }
  }
}

void Game::Update()
{
  if (!snake.alive)
    return;

  snake.Update();

  int new_x = static_cast<int>(snake.head_x);
  int new_y = static_cast<int>(snake.head_y);

  // Check if there's food over here
  if (food.x == new_x && food.y == new_y)
  {
    score++;
    PlaceFood();
    // Grow snake and increase speed.
    snake.GrowBody();
    snake.speed += 0.02;
  }

  // Check if there's penalty food over here
  if (penalty_food.x == new_x && penalty_food.y == new_y)
  {
    score--;
    PlacePenaltyFood();
  }

  // Check if the snake has hit a wall
  for (auto const &wall : walls)
  {
    if (wall.x == new_x && wall.y == new_y)
    {
      snake.alive = false;
    }
  }

  CheckCollisionWithAISnake();
}

void Game::UpdateThread()
{
  std::cout << "inside update thread." << std::endl;
  while (true)
  {
    std::cout << "inside while" << std::endl;
    std::unique_lock<std::mutex> lock(mtx);

    // Wait for a short duration or until data_ready is true or running is false
    auto timeout = std::chrono::milliseconds(50); // Adjust timeout duration as needed
    if (!cv.wait_for(lock, timeout, [this]
                     { return data_ready || !running; }))
    {
      std::cout << "inside cv." << std::endl;
      continue;
    }

    // Check if termination signal is received
    if (!running)
    {
      break; // Exit loop if termination signal is set
    }

    std::cout << "outside cv." << std::endl;
    ai_snake.UpdateAI(food);
    int new_x = static_cast<int>(ai_snake.head_x);
    int new_y = static_cast<int>(ai_snake.head_y);

    // Check if there's food over here
    if (food.x == new_x && food.y == new_y)
    {
      PlaceFood();
      ai_snake.speed += 0.02;
    }
    
    data_ready = false;
    lock.unlock();
  }
}

void Game::CheckCollisionWithAISnake()
{
  int head_x = static_cast<int>(snake.head_x);
  int head_y = static_cast<int>(snake.head_y);

  // Check collision with AI snake's body
  for (auto const &point : ai_snake.body)
  {
    if (point.x == head_x && point.y == head_y)
    {
      snake.alive = false;
      return;
    }
  }

  // Check collision with AI snake's head
  if (static_cast<int>(ai_snake.head_x) == head_x &&
      static_cast<int>(ai_snake.head_y) == head_y)
  {
    snake.alive = false;
  }
}

int Game::GetScore() const { return score; }
int Game::GetSize() const { return snake.size; }