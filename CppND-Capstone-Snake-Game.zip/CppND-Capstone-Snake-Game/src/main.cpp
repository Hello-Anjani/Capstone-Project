#include <iostream>
#include "controller.h"
#include "game.h"
#include "renderer.h"

Difficulty currentDifficulty = Difficulty::Medium;

void SetDifficulty(Difficulty difficulty)
{
  currentDifficulty = difficulty;
}

int main()
{
  constexpr std::size_t kFramesPerSecond{60};
  constexpr std::size_t kMsPerFrame{1000 / kFramesPerSecond};
  constexpr std::size_t kScreenWidth{640};
  constexpr std::size_t kScreenHeight{640};
  constexpr std::size_t kGridWidth{32};
  constexpr std::size_t kGridHeight{32};

  std::cout << "Select Difficulty: 1 - Easy, 2 - Medium, 3 - Hard\n";
  int choice;
  std::cin >> choice;
  std::string currentPlayerName;
  std::cout << "Enter your name: ";
  std::cin >> currentPlayerName;
  switch (choice)
  {
  case 1:
    SetDifficulty(Difficulty::Easy);
    break;
  case 2:
    SetDifficulty(Difficulty::Medium);
    break;
  case 3:
    SetDifficulty(Difficulty::Hard);
    break;
  default:
    SetDifficulty(Difficulty::Medium);
  }
  
  Renderer renderer(kScreenWidth, kScreenHeight, kGridWidth, kGridHeight);
  Controller controller;
  Game game(kGridWidth, kGridHeight, currentDifficulty, currentPlayerName);
  game.Run(controller, renderer, kMsPerFrame);
  std::cout << "Game has terminated successfully!\n";
  std::cout << "Score: " << game.GetScore() << "\n";
  std::cout << "Size: " << game.GetSize() << "\n";
  return 0;
}