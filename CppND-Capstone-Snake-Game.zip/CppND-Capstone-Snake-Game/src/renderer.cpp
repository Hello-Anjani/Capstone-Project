#include "renderer.h"
#include <iostream>
#include <string>

Renderer::Renderer(const std::size_t screen_width,
                   const std::size_t screen_height,
                   const std::size_t grid_width, const std::size_t grid_height)
    : screen_width(screen_width),
      screen_height(screen_height),
      grid_width(grid_width),
      grid_height(grid_height),
      sdl_window(nullptr, &SDL_DestroyWindow), // Initialize with nullptr and custom deleter
      sdl_renderer(nullptr, &SDL_DestroyRenderer)
{
  // Initialize SDL
  if (SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    std::cerr << "SDL could not initialize.\n";
    std::cerr << "SDL_Error: " << SDL_GetError() << "\n";
  }

  sdl_window = std::unique_ptr<SDL_Window, decltype(&SDL_DestroyWindow)>(
      SDL_CreateWindow("Snake Game", SDL_WINDOWPOS_CENTERED,
                       SDL_WINDOWPOS_CENTERED, screen_width,
                       screen_height, SDL_WINDOW_SHOWN),
      &SDL_DestroyWindow);

  if (nullptr == sdl_window.get())
  {
    std::cerr << "Window could not be created.\n";
    std::cerr << " SDL_Error: " << SDL_GetError() << "\n";
  }

  // Create renderer
  sdl_renderer = std::unique_ptr<SDL_Renderer, decltype(&SDL_DestroyRenderer)>(
      SDL_CreateRenderer(sdl_window.get(), -1, SDL_RENDERER_ACCELERATED),
      &SDL_DestroyRenderer);

  if (nullptr == sdl_renderer.get())
  {
    std::cerr << "Renderer could not be created.\n";
    std::cerr << "SDL_Error: " << SDL_GetError() << "\n";
  }
}

Renderer::~Renderer()
{
  SDL_Quit();
  TTF_Quit();
}

void Renderer::Render(Snake const snake, SDL_Point const &food, SDL_Point const &penalty_food,
                      std::vector<SDL_Point> const &walls, Snake const &ai_snake)
{
  SDL_Rect block;
  block.w = screen_width / grid_width;
  block.h = screen_height / grid_height;

  // Clear screen
  SDL_SetRenderDrawColor(sdl_renderer.get(), 0x1E, 0x1E, 0x1E, 0xFF);
  SDL_RenderClear(sdl_renderer.get());

  // Render food
  SDL_SetRenderDrawColor(sdl_renderer.get(), 0xFF, 0xCC, 0x00, 0xFF);
  block.x = food.x * block.w;
  block.y = food.y * block.h;
  SDL_RenderFillRect(sdl_renderer.get(), &block);

  // Render penalty food
  SDL_SetRenderDrawColor(sdl_renderer.get(), 0xFF, 0x00, 0x00, 0xFF);
  block.x = penalty_food.x * block.w;
  block.y = penalty_food.y * block.h;
  SDL_RenderFillRect(sdl_renderer.get(), &block);

  // Render walls
  SDL_SetRenderDrawColor(sdl_renderer.get(), 0x00, 0x00, 0xFF, 0xFF);
  for (auto const &wall : walls)
  {
    block.x = wall.x * block.w;
    block.y = wall.y * block.h;
    SDL_RenderFillRect(sdl_renderer.get(), &block);
  }

  // Render snake's body
  SDL_SetRenderDrawColor(sdl_renderer.get(), 0xFF, 0xFF, 0xFF, 0xFF);
  for (SDL_Point const &point : snake.body)
  {
    block.x = point.x * block.w;
    block.y = point.y * block.h;
    SDL_RenderFillRect(sdl_renderer.get(), &block);
  }

  // Render snake's head
  block.x = static_cast<int>(snake.head_x) * block.w;
  block.y = static_cast<int>(snake.head_y) * block.h;
  if (snake.alive)
  {
    SDL_SetRenderDrawColor(sdl_renderer.get(), 0x00, 0x7A, 0xCC, 0xFF);
  }
  else
  {
    SDL_SetRenderDrawColor(sdl_renderer.get(), 0xFF, 0x00, 0x00, 0xFF);
  }
  SDL_RenderFillRect(sdl_renderer.get(), &block);

  // Render AI snake's body
  SDL_SetRenderDrawColor(sdl_renderer.get(), 0xFF, 0xFF, 0x00, 0xFF); // Different color for AI snake
  for (SDL_Point const &point : ai_snake.body)
  {
    block.x = point.x * block.w;
    block.y = point.y * block.h;
    SDL_RenderFillRect(sdl_renderer.get(), &block);
  }

  // Render AI snake's head
  block.x = static_cast<int>(ai_snake.head_x) * block.w;
  block.y = static_cast<int>(ai_snake.head_y) * block.h;
  SDL_SetRenderDrawColor(sdl_renderer.get(), 0x00, 0x00, 0xFF, 0xFF); // Different color for AI snake
  SDL_RenderFillRect(sdl_renderer.get(), &block);

  // Update Screen
  SDL_RenderPresent(sdl_renderer.get());
}

void Renderer::UpdateWindowTitle(int score, int fps)
{
  std::string title{"Snake Score: " + std::to_string(score) + " FPS: " + std::to_string(fps)};
  SDL_SetWindowTitle(sdl_window.get(), title.c_str());
}

void Renderer::DisplayHighScores(const std::vector<std::string> &playerNames, const std::vector<int> &highScores)
{
  std::string title{"High Scores:\n"};
  for (size_t i = 0; i < playerNames.size(); ++i)
  {
    title += playerNames[i] + ": " + std::to_string(highScores[i]) + "\n";
  }
  std::cout << title << std::endl;
}

void Renderer::RenderGameOver()
{
  SDL_SetRenderDrawColor(sdl_renderer.get(), 0, 0, 0, 255); // Black background
  SDL_RenderClear(sdl_renderer.get());

  // Set up the text color (white)
  SDL_Color textColor = {255, 255, 255, 255};

  // Load a font
  TTF_Font *font = TTF_OpenFont("path/to/font.ttf", 24); // You need to have a font file
  if (!font)
  {
    std::cerr << "Failed to load font: " << TTF_GetError() << std::endl;
    return;
  }

  // Create surface
  SDL_Surface *surfaceMessage = TTF_RenderText_Solid(font, "Game Over", textColor);
  SDL_Texture *message = SDL_CreateTextureFromSurface(sdl_renderer.get(), surfaceMessage);

  // Define where to render the text
  SDL_Rect messageRect;
  messageRect.x = screen_width / 4;
  messageRect.y = screen_height / 2 - 12;
  messageRect.w = screen_width / 2;
  messageRect.h = 24;

  // Render the text
  SDL_RenderCopy(sdl_renderer.get(), message, nullptr, &messageRect);

  // Update the screen
  SDL_RenderPresent(sdl_renderer.get());

  // Clean up
  SDL_FreeSurface(surfaceMessage);
  SDL_DestroyTexture(message);
  TTF_CloseFont(font);
}
